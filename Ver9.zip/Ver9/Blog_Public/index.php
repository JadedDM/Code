<?php

/**
 * Front controller
 *
 * PHP version 5.4
 */

 
 require '../../blog/config/autoloader.php';
 //require '../../blog/Framework/Router.php';
 
/**
 * Error and Exception handling
 */
error_reporting(E_ALL);
set_error_handler('Framework\Error::errorHandler');
set_exception_handler('Framework\Error::exceptionHandler');


/**
 * Sessions
 */
session_start();


/**
 * Routing
 */
$router = new Framework\Router();

// Add the routes
$router->add('', ['controller' => 'Home', 'action' => 'index']);
$router->add('login', ['controller' => 'Login', 'action' => 'new']);
$router->add('Signup', ['controller' => 'Signup', 'action' => 'new']);
$router->add('logout', ['controller' => 'Login', 'action' => 'destroy']);
$router->add('dashboard', ['controller' => 'Dashboard', 'action' => 'index']);
$router->add('{controller}/{action}');
    
$router->dispatch($_SERVER['QUERY_STRING']);
