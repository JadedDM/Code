<?php
namespace Framework;


class DashboardGenerator
{
			// Function to generate 1, 2, or 4 squares HTML based on user role
		function generateDashboardSquares(String $role) 
		{
		   // $userRole = getUserRole();
			$squareData = [];

			// Define square data based on user role
			switch ($role) {
				case 'Research Group Manager':
					$squareData = [
					['text' => 'Create New Study', 'link' => '#'],
					['text' => 'View All Studies', 'link' => '#'],
					['text' => 'Delete Previous Studies', 'link' => '#'],
					['text' => 'Create New Researcher', 'link' => '#']
					];
					break;

				case 'Research Study Manager':
					$squareData = [
					  ['text' => 'Create New Study', 'link' => '#'],
					  ['text' => 'View All Studies', 'link' => '#'],
					  ['text' => 'Delete Previous Studies', 'link' => '#'],
					
					];
					break;

				case 'Researcher':
					$squareData = [
					   ['text' => 'View All Studies', 'link' => '#'],
					];
					break;

				default:
					 $htmlString = '<h5>Not Authorize</h5>';
					break;
			}

			// Generate HTML for squares
			$htmlString = '';

			foreach ($squareData as $square) {
				$htmlString .= '<div class="row mt-4 justify-content-center">' .
				     '<div class="col-md-6">' . // Adjust column size based on your layout
					
					'<h5 class="square"><a href="' . $square['link'] . '">' . $square['text'] . '</a></h5>' .
					
					'</div>' .
					'</div>';
			}

			return $htmlString;
		}
		
}