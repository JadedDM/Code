<?php

namespace Framework;

/**
 * Error and exception handler

 */
abstract class AbstractError
{

    /**
     * Error handler. Convert all errors to Exceptions by throwing an ErrorException.
     *
     * int $level  Error level
     * string $message  Error message
     * string $file  Filename the error was raised in
     * int $line  Line number in the file
     *
     * 
     */
    abstract public static function errorHandler($level, $message, $file, $line);
  
    /**
     * Exception handler.
     *
     * @param Exception $exception  The exception
     *
     * @return void
     */
    abstract public static function exceptionHandler($exception);

}





