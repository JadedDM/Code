<?php
namespace Framework;

/*
abstract view class 
*/


abstract class AbstractView
{
    protected static $data = [];

    public static function assign($key, $value)
    {
        self::$data[$key] = $value;
    }

    /**
     * Render data to view file
     * $templateFile The view file location
     * array $data optional Associative array of data to display in the view
     */
    abstract public static function render($templateFile, $data = []);
}
