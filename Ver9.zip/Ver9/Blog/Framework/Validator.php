<?php

namespace Framework;

class Validator
{


   private $errors = '';

  


        public function isregValid(array $userData) : bool
	   {
		  $validEmail = $this->isEmailValid($userData['email']);
		  $validPassword = $this->isPasswordValid($userData['password']);
		  $validUsername = $this->isUsernameValid($userData['username']);

		  
			if(!$validEmail  ||!$validPassword || !$validUsername){
				$this->errors.= 'Registration Format: Invalid Input Format';
				return false;
			}

			return true;

				
		}







	  public function isloginValid(array $userData): bool
	  {
		  $validEmail = $this->isEmailValid($userData['email']);
		  $validPassword = $this->isPasswordValid($userData['password']);

			if(!$validEmail  ||!$validPassword){
			  $this->errors .= 'Login Format: Email or Password Format is Invalid.<br>';
				return false;
			}

		  return true;
		  
	  }
	  
  
  
	  public function isEmailValid($email) :bool{

		    

			if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
				$this->errors .= 'Email: Email Format is Invalid<br>';
				return false;
			}
			return true;
		}  



		public function isPasswordValid(string $passwd) : bool
		{

			$isUpLetter = false;
			$isNumber = false;
			$str = $passwd;
			
			//pattern to test length and alphanumeric
			$Pattern = "(^[A-Za-z0-9]{10,18}$)";
			
			$uppercasePattern = '/[A-Z]/';
			$numberPattern = '/[0-9]/';
			
			
			$uppercase = preg_match($uppercasePattern, $str);
			$number = preg_match($numberPattern, $str);

			//check if pattern entered is correct 
			if (!preg_match($Pattern, $str)){
				 $this->errors .= 'Password: Password must be at least 10 characters and only alphanumeric.<br>';
			  return false;
			}
			 
			//check for uppercase letter
			if(!$uppercase){
			   $this->errors .= 'Password: Password must contain at least 1 uppercase letter.<br>';

			   return false;

			}
			
			if (!$number){
				$this->errors .= 'Password: Password must contain at least 1 digit.<br>';
				return false;
			}

			return true;

		}     


		public function isUsernameValid(string $username) : bool
		{
			
			
			$Pattern = "(^[a-zA-Z0-9]{6,15}$)";
			   
			//check if pattern entered is correct 
			if (!preg_match($Pattern, $username)){
				$this->errors['username'] ='Username is invalid.<br>';
			   return false;
			}
			 
		   
			return true;
	
		}     
	
      
	  
	  
		   
	   /** 
		* * attach error message to string
		 */
			public function getErrorMessages()
			{
						
				$errors = $this->errors;
				return $errors;

			}








}