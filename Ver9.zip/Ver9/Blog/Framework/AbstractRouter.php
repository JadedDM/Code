<?php

namespace Framework;

/**
 * Abstract Router
 */
abstract class AbstractRouter
{

    /**
     * Associative array of routes (the routing table)
    */
    protected $routes = [];

    /**
     * Parameters from the matched route
    */
    protected $params = [];

    /**
     * Add a route to the routing table
     *
     * $route  The route URL
     * $params Parameters eg (controller, action, etc.)
     */
    public function add($route, $params = [])
    {
		
        // Convert the route to a regular expression: escape forward slashes
        $route = preg_replace('/\//', '\\/', $route);

        // Convert variables e.g. {controller}
        $route = preg_replace('/\{([a-z]+)\}/', '(?P<\1>[a-z-]+)', $route);

        // Convert variables with custom regular expressions e.g. {id:\d+}
        $route = preg_replace('/\{([a-z]+):([^\}]+)\}/', '(?P<\1>\2)', $route);

        // Add start and end delimiters, and case insensitive flag
        $route = '/^' . $route . '$/i';

        $this->routes[$route] = $params;
    }

    /**
     * Get all the routes from  routing table
     * return as array
     */
    public function getRoutes()
    {
        return $this->routes;
    }

    /**
     * Match the route to the routes in the routing table
     * $params = property if a route is found.
     *
     * string $url The route URL
     *
     * return true if a match found, false otherwise
     */
    public function match($url)
    {
        foreach ($this->routes as $route => $params) {
            if (preg_match($route, $url, $matches)) {
                
                foreach ($matches as $key => $match) {
                    if (is_string($key)) {
                        $params[$key] = $match;
                    }
                }

                $this->params = $params;
                return true;
            }
        }

        return false;
    }

 
    public function getParams()
    {
        return $this->params;
    }

    /**
     * Dispatch the route, creating new controller object and call the
     * action method
     *
     */
 abstract public function dispatch($url);

}
