<?php
namespace Framework;

class FormGenerator
{
    //would have been better as traits 
    public function generateRegistrationForm()
    {
        $form = '<form action="/Blog_Public/signup/create" method="post" class="container mt-5">';
        $form .= '<div class="form-group">';
        $form .= '<label for="username">Username:</label>';
        $form .= '<input type="text" name="username" id="username" class="form-control" required>';
        $form .= '</div>';
        $form .= '<div class="form-group">';
        $form .= '<label for="email">Email:</label>';
        $form .= '<input type="email" name="email" id="email" class="form-control" required>';
        $form .= '</div>';
        $form .= '<div class="form-group">';
        $form .= '<label for="password">Password:</label>';
        $form .= '<input type="password" name="password" id="password" class="form-control" required>';
        $form .= '</div>';
        $form .= '<button type="submit" class="btn btn-primary">Register</button>';
        $form .= '</form>';

        return $form;
    }

    public function generateLoginForm()
    {
        $form = '<form action="/Blog_Public/login/create" method="post" class="container mt-5">';
        $form .= '<div class="form-group">';
        $form .= '<label for="email">Email:</label>';
        $form .= '<input type="text" name="email" id="email" class="form-control" required>';
        $form .= '</div>';
        $form .= '<div class="form-group">';
        $form .= '<label for="password">Password:</label>';
        $form .= '<input type="password" name="password" id="password" class="form-control" required>';
        $form .= '</div>';
        $form .= '<button type="submit" class="btn btn-primary">Login</button>';
        $form .= '</form>';

        return $form;
    }
}
