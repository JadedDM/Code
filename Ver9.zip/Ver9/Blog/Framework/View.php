<?php
namespace Framework;

/*
view class which is the Template Engine

*/



class View extends \Framework\AbstractView
{
    public static function render($templateFile, $data = [])
    {
        $file = VIEWS_DIR . "/$templateFile";

        if (file_exists($file)) {
            self::$data += $data;

            extract(self::$data);
            include $file;
        } else {
            throw new \Exception("$file not found");
        }
    }
}

    
