<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sign up
</title>
</head>
<body>
    <h1>Sign up</h1>

    <form method="post" action="/Blog_Public/signup/create">

        <div>
            <label for="inputName">username</label>
            <input id="userame" name="username" placeholder="username" autofocus />
        </div>
        <div>
            <label for="inputEmail">Email address</label>
            <input id="email" name="email" placeholder="email address" />
        </div>
        <div>
            <label for="inputPassword">Password</label>
            <input type="password" id="password" name="password" placeholder="Password" />
        </div>
     

        <button type="submit">Sign up</button>

    </form>

</body>
</html>

