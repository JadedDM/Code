<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>
<body>
    <h1>Welcome</h1>
   
  <p><?= $uname ?></p>

  <?php
  //print_r($_SESSION);
 
  print_r( $_SESSION['session_user']['email']);

  ?>

  <a href="/Blog_Public/logout">Log out</a>
  
</body>
</html>
