<!DOCTYPE html>
<html>

<head>
  <title>Login Page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-4">
            <!-- Logo in the left corner -->
            <img alt="Logo" class="img-fluid" width="80" height="80">
        </div>
        <div class="col-md-5"> 
            <!-- website name -->
            <h2>Research Management System</h2>
        </div>
    </div>
	
	 <nav class="navbar navbar-expand-sm bg-light navbar-light">
  <ul class="navbar-nav">
    <li class="nav-item active">
      <a class="nav-link" href="/BLOG_Public/Login">Login</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="/BLOG_Public/Signup">Register</a>
    </li>
  </ul>
</nav>
<li style="color: red; font-weight: bold;"><?= $err ?></li>

<?= $form ?>
  </body>

  <footer id="my-footer" class="mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <p>Copyright&copy; Dana Ramsey. All Rights Reserved</p>
            </div>
        </div>
    </div>
</footer>
</html>