<!DOCTYPE html>
<html>
    
    


   <h1>Log in</h1>

   <p><?= $em ?></p>

    <form action="/Blog_Public/login/create" method="post">

        <div>
            <label for="inputEmail">Email address</label>
            <input type="email" id="Email" name="email" placeholder="Email address" autofocus value="{{ email }}" />
        </div>
        <div>
            <label for="inputPassword">Password</label>
            <input type="password" id="inputPassword" name="password" placeholder="Password" />
        </div>

        <button type="submit">Log in</button>

    </form>


</html>