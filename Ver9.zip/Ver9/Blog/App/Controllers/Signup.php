<?php

namespace App\Controllers;

use \Framework\View;
use \Framework\FormGenerator;
use \App\Models\User;
use \Framework\Validator;

/**
 * Signup controller
 *
 *
 */
class Signup extends \Framework\Controller
{
    /**
     * Show the signup page
     *
     * @return void
     */
    public function newAction()
    {

        $this->signupDisplay();

    }
  
   /**
     * Sign up a new user
     *
     * @return void
     */
    public function createAction()
    {
        $valid = new Validator();
        if (!$valid->isregValid($_POST))
        {
            $err = $valid->getErrorMessages();
          
                $this ->signupDisplay($err);

     
        }

          $user = new User($_POST);

        if ($user->save()) {

            View::render('Signup/success.html');

        } else {

            View::render('Signup/new.html', [
                'user' => $user
            ]);

        }
    }

  
  //uses to send values to template
  
    public function signupDisplay($var="" )
    {
 
     $formGenerator = new FormGenerator();
     $regForm = $formGenerator->generateRegistrationForm();
     
     
     $data = 
                 [
                     'err' =>  $var,
                     'form' => $regForm
 
                 ]; 	
 
                 View::render('Signup/new.html',$data);
 
   }
 
 
  
  
}
