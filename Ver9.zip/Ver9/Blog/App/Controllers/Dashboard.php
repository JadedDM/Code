<?php

namespace App\Controllers;


use \Framework\View;
use \Framework\DashboardGenerator;
use \Framework\Auth;



/**
 * Dashboard controller
 */
class Dashboard extends \Framework\Controller
{

  
    public function indexAction()
    {
        
        if (! Auth::isLoggedIn()) {
            $this->redirect('/login');
        }
        
        $role= $_SESSION['session_user']['role'];;
        $email=  $_SESSION['session_user']['email']; 
        $uname=  $_SESSION['session_user']['uname'];
        $this->DashboardDisplay($role, $email, $uname);

		
  
        
       
    }




    public function DashboardDisplay($role="", $email= "", $uname= "")
    {

        $menuGenerator = new DashboardGenerator();
        $menu = $menuGenerator->generateDashboardSquares($role);

        $data = 
                [
                    'role' =>  $role,
                    'uname' => $uname,
                    'em' => $email,
                    'menu' => $menu
            
                ]; 	

            View::render('Dashboard/index.html',$data);

    }









}