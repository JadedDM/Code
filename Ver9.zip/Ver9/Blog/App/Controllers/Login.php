<?php

namespace App\Controllers;

use \Framework\View;
use \App\Models\User;
use \Framework\FormGenerator;
use \Framework\Validator;
use \Framework\Auth;

/**
 * Login controller
 */
class Login extends \Framework\Controller
{


    /**
     * Show the login page
     *
     * @return void
     */
    public function newAction()
    {
         $this ->LoginDisplay();
    

    }

 /**
     * Log in a user
     *
   */
    public function createAction()
    {
       
            $valid = new Validator();
            if (!$valid->isloginValid($_POST))
            {
                $err = $valid->getErrorMessages();

                $this ->LoginDisplay($err);
                exit;
                        

              }


        $user = User::authenticate($_POST['email'], $_POST['password']);

        if ($user) 
        {
            Auth::login($user);
            /*
            $test = $_SESSION['session_user']['email'];
            $data = 
            [
                'uname' => $test//"success "
            ];
    
            View::render('Dashboard/index.php',$data);
           */
          $this->redirect('/Dashboard');
        
        } 
        else 
        {
    
          
          $err = "Email or Password is Invalid";
             
           $this ->LoginDisplay($err);
           exit;
           
        }




    }

    
    /**
     * Log out a user
     *
     * @return void
     */
    
    public function destroyAction()
    {
        Auth::logout();

        $this->redirect('/');
    }



   public function LoginDisplay($var="" )
   {

    $formGenerator = new FormGenerator();
    $loginForm = $formGenerator->generateLoginForm();
    
    
    $data = 
                [
                    'err' =>  $var,
                    'form' => $loginForm

                ]; 	

                View::render('Login/Login.php',$data);
            
                

  }





}







