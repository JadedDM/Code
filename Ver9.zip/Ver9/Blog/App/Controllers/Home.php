<?php

namespace App\Controllers;

use \Framework\View;

/**
 * Home controller
 */
class Home extends \Framework\Controller
{

  
    public function indexAction()
    {
		
		
        View::render('Home/index.html');
        exit;
        
       
    }
}
