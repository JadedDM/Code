<?php



 //DATABASE INFO
 const DB_USER = 'root';
 const DB_NAME = 'user_management_system';
 const DB_HOST = 'localhost';
 const DB_PASSWORD = '';

//If true display errors to screen
//When false errors saved to log
 const SHOW_ERRORS = false;

//DIRECTORIES

define('ROOT_DIR', 'C:\xampp\blog');
define('APP_DIR', ROOT_DIR . '\app');
define('FRAMEWORK_DIR', ROOT_DIR . '\Framework');
define('TPL_DIR', ROOT_DIR . '\tpl');
define('CONFIG_DIR', ROOT_DIR . '\config');
define('LOG_DIR', ROOT_DIR . '\Logs');
define('LOGO', ROOT_DIR .'images\logo.png');


//APP Subfolder
define('VIEWS_DIR', APP_DIR . '\views');
define('CONTROLLERS_DIR', APP_DIR . '\controllers');
define('MODELS_DIR', APP_DIR . '\models');



 
 
 
 
 
 




