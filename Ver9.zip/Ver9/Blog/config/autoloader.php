<?php

require_once 'config.php';
 

class Autoloader
{
    private static $baseDir;

    public static function setBaseDir($dir)
    {
        self::$baseDir = rtrim($dir, DIRECTORY_SEPARATOR);
    }

    public static function register()
    {
        spl_autoload_register([self::class, 'autoload']);
    }

    public static function autoload($className)
    {
        $file = self::convertNamespaceToPath($className);

        if (file_exists($file)) {
            require_once $file;
        }
    }

    private static function convertNamespaceToPath($className)
    {
        $namespace = explode('\\', $className);
        $namespace = array_map('lcfirst', $namespace);
        $class = array_pop($namespace);

        $path = implode(DIRECTORY_SEPARATOR, $namespace);
        $path .= DIRECTORY_SEPARATOR . $class . '.php';

        return self::$baseDir . DIRECTORY_SEPARATOR . $path;
    }
}

// Set the absolute directory path for your project
//Autoloader::setBaseDir('C:\xampp\Blog');
Autoloader::setBaseDir(ROOT_DIR);

// Register the autoloader
Autoloader::register();
